import React, { useState } from 'react';
import { Save, Upload, Trash2, Download } from 'lucide-react';
import { useAppStore } from '../store';

export const PresetManager: React.FC = () => {
  const { savePreset, loadPreset, getPresets, deletePreset, mappings } = useAppStore();
  const [presetName, setPresetName] = useState('');
  const [presets, setPresets] = useState<string[]>([]);
  const [showSaveDialog, setShowSaveDialog] = useState(false);

  React.useEffect(() => {
    setPresets(getPresets());
  }, [getPresets]);

  const handleSavePreset = () => {
    if (presetName.trim()) {
      savePreset(presetName.trim());
      setPresets(getPresets());
      setPresetName('');
      setShowSaveDialog(false);
    }
  };

  const handleLoadPreset = (name: string) => {
    loadPreset(name);
  };

  const handleDeletePreset = (name: string) => {
    if (confirm(`Delete preset "${name}"?`)) {
      deletePreset(name);
      setPresets(getPresets());
    }
  };

  const handleExportMappings = () => {
    const dataStr = JSON.stringify(mappings, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `cc-router-mappings-${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleImportMappings = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const importedMappings = JSON.parse(e.target?.result as string);
          if (Array.isArray(importedMappings)) {
            useAppStore.getState().setMappings(importedMappings);
          }
        } catch (error) {
          alert('Invalid mapping file format');
        }
      };
      reader.readAsText(file);
    }
    // Reset the input
    event.target.value = '';
  };

  return (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <h3 className="text-lg font-semibold text-white mb-4">Preset Manager</h3>
      
      <div className="space-y-4">
        {/* Save new preset */}
        <div>
          {!showSaveDialog ? (
            <button
              onClick={() => setShowSaveDialog(true)}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-md transition-colors w-full justify-center"
            >
              <Save className="h-4 w-4" />
              Save Current Mappings
            </button>
          ) : (
            <div className="space-y-2">
              <input
                type="text"
                value={presetName}
                onChange={(e) => setPresetName(e.target.value)}
                placeholder="Enter preset name..."
                className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                onKeyPress={(e) => e.key === 'Enter' && handleSavePreset()}
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  onClick={handleSavePreset}
                  disabled={!presetName.trim()}
                  className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white px-3 py-1 rounded text-sm transition-colors"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setShowSaveDialog(false);
                    setPresetName('');
                  }}
                  className="flex-1 bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded text-sm transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Preset list */}
        {presets.length > 0 && (
          <div>
            <h4 className="text-sm font-medium text-gray-300 mb-2">Saved Presets</h4>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {presets.map((preset) => (
                <div
                  key={preset}
                  className="flex items-center justify-between bg-gray-700 rounded-md px-3 py-2"
                >
                  <span className="text-white text-sm truncate flex-1">{preset}</span>
                  <div className="flex gap-1 ml-2">
                    <button
                      onClick={() => handleLoadPreset(preset)}
                      className="p-1 text-gray-400 hover:text-ableton-400 transition-colors"
                      title="Load preset"
                    >
                      <Upload className="h-3 w-3" />
                    </button>
                    <button
                      onClick={() => handleDeletePreset(preset)}
                      className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                      title="Delete preset"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Import/Export */}
        <div className="border-t border-gray-700 pt-4">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Import/Export</h4>
          <div className="flex gap-2">
            <button
              onClick={handleExportMappings}
              className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-md transition-colors text-sm"
            >
              <Download className="h-4 w-4" />
              Export
            </button>
            <label className="flex-1 flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-md transition-colors text-sm cursor-pointer">
              <Upload className="h-4 w-4" />
              Import
              <input
                type="file"
                accept=".json"
                onChange={handleImportMappings}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Quick actions */}
        <div className="border-t border-gray-700 pt-4">
          <h4 className="text-sm font-medium text-gray-300 mb-2">Quick Actions</h4>
          <div className="space-y-2">
            <button
              onClick={() => {
                if (confirm('Reset all mappings to default Launch Control XL3 layout?')) {
                  const defaultMappings = Array.from({ length: 8 }, (_, i) => ({
                    id: (i + 1).toString(),
                    ccNumber: 13 + i,
                    deviceIndex: 0,
                    parameterIndex: i,
                    parameterName: `Knob ${i + 1}`,
                    curve: 'linear' as const
                  }));
                  useAppStore.getState().setMappings(defaultMappings);
                }
              }}
              className="w-full bg-yellow-600 hover:bg-yellow-700 text-white px-3 py-2 rounded-md transition-colors text-sm"
            >
              Reset to XL3 Defaults
            </button>
            <button
              onClick={() => {
                if (confirm('Clear all mappings?')) {
                  useAppStore.getState().setMappings([]);
                }
              }}
              className="w-full bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md transition-colors text-sm"
            >
              Clear All Mappings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
