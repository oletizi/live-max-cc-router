import React from 'react';
import { Music, RefreshCw } from 'lucide-react';
import { useAppStore } from '../store';

interface MIDIDeviceSelectorProps {
  onDeviceSelect: (deviceId: string) => void;
  onRefresh: () => void;
}

export const MIDIDeviceSelector: React.FC<MIDIDeviceSelectorProps> = ({
  onDeviceSelect,
  onRefresh
}) => {
  const { availableDevices, selectedDeviceId } = useAppStore();

  return (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Music className="h-5 w-5" />
          MIDI Device
        </h3>
        <button
          onClick={onRefresh}
          className="p-1 text-gray-400 hover:text-white transition-colors"
          title="Refresh device list"
        >
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>
      
      <select
        value={selectedDeviceId || ''}
        onChange={(e) => onDeviceSelect(e.target.value)}
        className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-ableton-500 focus:border-transparent"
      >
        <option value="">Select MIDI device...</option>
        {availableDevices.map(device => (
          <option key={device.id} value={device.id}>
            {device.name || `Device ${device.id}`}
          </option>
        ))}
      </select>
      
      {availableDevices.length === 0 && (
        <p className="text-gray-400 text-sm mt-2">
          No MIDI devices found. Connect your Launch Control XL3 and refresh.
        </p>
      )}
      
      {selectedDeviceId && (
        <div className="mt-2 p-2 bg-green-900/20 border border-green-800 rounded text-green-400 text-sm">
          Connected to: {availableDevices.find(d => d.id === selectedDeviceId)?.name}
        </div>
      )}
    </div>
  );
};
