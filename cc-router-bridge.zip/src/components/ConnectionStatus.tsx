import React from 'react';
import { Wifi, WifiOff, Activity } from 'lucide-react';
import { useAppStore } from '../store';

export const ConnectionStatus: React.FC = () => {
  const { connectionStatus } = useAppStore();

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <Wifi className="h-4 w-4 text-green-500" />;
      case 'connecting':
        return <Activity className="h-4 w-4 text-yellow-500 animate-pulse" />;
      case 'error':
        return <WifiOff className="h-4 w-4 text-red-500" />;
      default:
        return <WifiOff className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'connected':
        return 'Connected';
      case 'connecting':
        return 'Connecting...';
      case 'error':
        return 'Error';
      default:
        return 'Disconnected';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'text-green-500';
      case 'connecting':
        return 'text-yellow-500';
      case 'error':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <h3 className="text-lg font-semibold mb-3 text-white">Connection Status</h3>
      
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-gray-300">MIDI Device:</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(connectionStatus.midi)}
            <span className={`text-sm ${getStatusColor(connectionStatus.midi)}`}>
              {getStatusText(connectionStatus.midi)}
            </span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-gray-300">OSC Bridge:</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(connectionStatus.osc)}
            <span className={`text-sm ${getStatusColor(connectionStatus.osc)}`}>
              {getStatusText(connectionStatus.osc)}
            </span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-gray-300">Ableton Live:</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(connectionStatus.live)}
            <span className={`text-sm ${getStatusColor(connectionStatus.live)}`}>
              {getStatusText(connectionStatus.live)}
            </span>
          </div>
        </div>
      </div>
      
      {connectionStatus.midi === 'error' && (
        <div className="mt-3 p-2 bg-red-900/20 border border-red-800 rounded text-red-400 text-sm">
          WebMIDI access denied or not supported. Please enable MIDI access in your browser.
        </div>
      )}
      
      {connectionStatus.osc === 'error' && (
        <div className="mt-3 p-2 bg-red-900/20 border border-red-800 rounded text-red-400 text-sm">
          OSC bridge connection failed. Make sure the Max for Live device is loaded.
        </div>
      )}
    </div>
  );
};
