import React, { useState } from 'react';
import { Plus, Trash2, Edit3, Save, X } from 'lucide-react';
import { useAppStore } from '../store';
import { ParameterMapping } from '../types';

export const ParameterMappingEditor: React.FC = () => {
  const { mappings, addMapping, updateMapping, removeMapping } = useAppStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<ParameterMapping>>({});

  const startEditing = (mapping: ParameterMapping) => {
    setEditingId(mapping.id);
    setEditForm(mapping);
  };

  const saveEdit = () => {
    if (editingId && editForm) {
      updateMapping(editingId, editForm);
      setEditingId(null);
      setEditForm({});
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({});
  };

  const addNewMapping = () => {
    const newMapping: ParameterMapping = {
      id: Date.now().toString(),
      ccNumber: 21,
      deviceIndex: 0,
      parameterIndex: 0,
      parameterName: 'New Parameter',
      curve: 'linear'
    };
    addMapping(newMapping);
    startEditing(newMapping);
  };

  const curves = [
    { value: 'linear', label: 'Linear' },
    { value: 'exponential', label: 'Exponential' },
    { value: 'logarithmic', label: 'Logarithmic' }
  ];

  return (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Parameter Mappings</h3>
        <button
          onClick={addNewMapping}
          className="flex items-center gap-2 bg-ableton-600 hover:bg-ableton-700 text-white px-3 py-1 rounded-md transition-colors"
        >
          <Plus className="h-4 w-4" />
          Add Mapping
        </button>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {mappings.map((mapping) => (
          <div
            key={mapping.id}
            className="bg-gray-700 border border-gray-600 rounded-md p-3"
          >
            {editingId === mapping.id ? (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">CC Number</label>
                    <input
                      type="number"
                      value={editForm.ccNumber || ''}
                      onChange={(e) => setEditForm({
                        ...editForm,
                        ccNumber: parseInt(e.target.value) || 0
                      })}
                      className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                      min="0"
                      max="127"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Device Index</label>
                    <input
                      type="number"
                      value={editForm.deviceIndex || ''}
                      onChange={(e) => setEditForm({
                        ...editForm,
                        deviceIndex: parseInt(e.target.value) || 0
                      })}
                      className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                      min="0"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Parameter Index</label>
                    <input
                      type="number"
                      value={editForm.parameterIndex || ''}
                      onChange={(e) => setEditForm({
                        ...editForm,
                        parameterIndex: parseInt(e.target.value) || 0
                      })}
                      className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Curve</label>
                    <select
                      value={editForm.curve || 'linear'}
                      onChange={(e) => setEditForm({
                        ...editForm,
                        curve: e.target.value as 'linear' | 'exponential' | 'logarithmic'
                      })}
                      className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                    >
                      {curves.map(curve => (
                        <option key={curve.value} value={curve.value}>
                          {curve.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-1">Parameter Name</label>
                  <input
                    type="text"
                    value={editForm.parameterName || ''}
                    onChange={(e) => setEditForm({
                      ...editForm,
                      parameterName: e.target.value
                    })}
                    className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                    placeholder="Parameter description..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Min Value (optional)</label>
                    <input
                      type="number"
                      value={editForm.minValue || ''}
                      onChange={(e) => setEditForm({
                        ...editForm,
                        minValue: e.target.value ? parseFloat(e.target.value) : undefined
                      })}
                      className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                      step="0.01"
                      min="0"
                      max="1"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Max Value (optional)</label>
                    <input
                      type="number"
                      value={editForm.maxValue || ''}
                      onChange={(e) => setEditForm({
                        ...editForm,
                        maxValue: e.target.value ? parseFloat(e.target.value) : undefined
                      })}
                      className="w-full bg-gray-600 border border-gray-500 rounded px-2 py-1 text-white text-sm"
                      step="0.01"
                      min="0"
                      max="1"
                    />
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={saveEdit}
                    className="flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white px-2 py-1 rounded text-sm transition-colors"
                  >
                    <Save className="h-3 w-3" />
                    Save
                  </button>
                  <button
                    onClick={cancelEdit}
                    className="flex items-center gap-1 bg-gray-600 hover:bg-gray-700 text-white px-2 py-1 rounded text-sm transition-colors"
                  >
                    <X className="h-3 w-3" />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-ableton-400 font-mono">CC {mapping.ccNumber}</span>
                    <span className="text-gray-400">→</span>
                    <span className="text-gray-300">Device {mapping.deviceIndex}</span>
                    <span className="text-gray-400">→</span>
                    <span className="text-gray-300">Param {mapping.parameterIndex}</span>
                    <span className="text-gray-500">({mapping.curve})</span>
                  </div>
                  <div className="text-white text-sm mt-1">{mapping.parameterName}</div>
                  {(mapping.minValue !== undefined || mapping.maxValue !== undefined) && (
                    <div className="text-gray-400 text-xs mt-1">
                      Range: {mapping.minValue ?? 0} - {mapping.maxValue ?? 1}
                    </div>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => startEditing(mapping)}
                    className="p-1 text-gray-400 hover:text-white transition-colors"
                    title="Edit mapping"
                  >
                    <Edit3 className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => removeMapping(mapping.id)}
                    className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                    title="Delete mapping"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {mappings.length === 0 && (
        <div className="text-center py-8 text-gray-400">
          <p>No parameter mappings configured.</p>
          <p className="text-sm mt-1">Click "Add Mapping" to get started.</p>
        </div>
      )}
    </div>
  );
};
