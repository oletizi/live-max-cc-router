import React, { useEffect, useState } from 'react';
import { Activity, Volume2 } from 'lucide-react';
import { useAppStore } from '../store';
import { MIDIMessage } from '../types';

export const MIDIActivityMonitor: React.FC = () => {
  const { lastCCMessage, mappings } = useAppStore();
  const [recentMessages, setRecentMessages] = useState<MIDIMessage[]>([]);
  const [activityIndicator, setActivityIndicator] = useState(false);

  useEffect(() => {
    if (lastCCMessage) {
      setRecentMessages(prev => {
        const updated = [lastCCMessage, ...prev.slice(0, 9)]; // Keep last 10 messages
        return updated;
      });

      // Flash activity indicator
      setActivityIndicator(true);
      const timer = setTimeout(() => setActivityIndicator(false), 200);
      return () => clearTimeout(timer);
    }
  }, [lastCCMessage]);

  const getMappingForCC = (ccNumber: number) => {
    return mappings.find(m => m.ccNumber === ccNumber);
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });
  };

  return (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Volume2 className="h-5 w-5" />
          MIDI Activity
        </h3>
        <div className="flex items-center gap-2">
          <Activity 
            className={`h-4 w-4 transition-colors ${
              activityIndicator ? 'text-green-400' : 'text-gray-500'
            }`} 
          />
          <span className="text-sm text-gray-400">
            {recentMessages.length > 0 ? 'Active' : 'Waiting...'}
          </span>
        </div>
      </div>

      {lastCCMessage && (
        <div className="mb-4 p-3 bg-gray-700 rounded-md border-l-4 border-ableton-500">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-ableton-400 font-mono text-sm">
                CC {lastCCMessage.ccNumber}
              </span>
              <span className="text-gray-400 mx-2">→</span>
              <span className="text-white text-sm">
                Value: {lastCCMessage.value}
              </span>
            </div>
            <span className="text-gray-400 text-xs">
              {formatTimestamp(lastCCMessage.timestamp)}
            </span>
          </div>
          
          {getMappingForCC(lastCCMessage.ccNumber) && (
            <div className="mt-2 text-xs text-gray-300">
              Mapped to: {getMappingForCC(lastCCMessage.ccNumber)?.parameterName}
            </div>
          )}
        </div>
      )}

      <div className="space-y-1 max-h-48 overflow-y-auto">
        <h4 className="text-sm font-medium text-gray-300 mb-2">Recent Messages</h4>
        
        {recentMessages.length === 0 ? (
          <div className="text-center py-4 text-gray-500 text-sm">
            No MIDI messages received yet.
            <br />
            Move a control on your Launch Control XL3.
          </div>
        ) : (
          recentMessages.map((message, index) => {
            const mapping = getMappingForCC(message.ccNumber);
            const normalizedValue = (message.value / 127 * 100).toFixed(0);
            
            return (
              <div
                key={`${message.timestamp}-${index}`}
                className={`flex items-center justify-between p-2 rounded text-xs ${
                  index === 0 
                    ? 'bg-gray-600 border border-ableton-600' 
                    : 'bg-gray-700/50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className="font-mono text-ableton-400 w-8">
                    CC{message.ccNumber}
                  </span>
                  <div className="w-16 bg-gray-800 rounded-full h-2">
                    <div
                      className="bg-ableton-500 h-2 rounded-full transition-all"
                      style={{ width: `${normalizedValue}%` }}
                    />
                  </div>
                  <span className="text-white w-8 text-right">
                    {message.value}
                  </span>
                  {mapping && (
                    <span className="text-gray-300 truncate max-w-32">
                      {mapping.parameterName}
                    </span>
                  )}
                </div>
                <span className="text-gray-500 text-xs">
                  {formatTimestamp(message.timestamp)}
                </span>
              </div>
            );
          })
        )}
      </div>

      {recentMessages.length > 0 && (
        <button
          onClick={() => setRecentMessages([])}
          className="mt-3 w-full text-xs text-gray-400 hover:text-white transition-colors py-1"
        >
          Clear History
        </button>
      )}
    </div>
  );
};
