export interface MIDIMessage {
  ccNumber: number;
  value: number;
  channel: number;
  timestamp: number;
}

export interface ParameterMapping {
  id: string;
  ccNumber: number;
  deviceIndex: number;
  parameterIndex: number;
  parameterName: string;
  minValue?: number;
  maxValue?: number;
  curve?: 'linear' | 'exponential' | 'logarithmic';
}

export interface TrackInfo {
  id: number;
  name: string;
  isSelected: boolean;
  deviceCount: number;
}

export interface DeviceInfo {
  index: number;
  name: string;
  parameterCount: number;
  parameters: ParameterInfo[];
}

export interface ParameterInfo {
  index: number;
  name: string;
  value: number;
  min: number;
  max: number;
}

export interface AppState {
  isConnected: boolean;
  selectedDeviceId: string | null;
  availableDevices: MIDIInput[];
  mappings: ParameterMapping[];
  selectedTrackId: number | null;
  tracks: TrackInfo[];
  lastCCMessage: MIDIMessage | null;
}

export interface OSCMessage {
  address: string;
  args: (number | string)[];
}

export interface ConnectionStatus {
  midi: 'disconnected' | 'connecting' | 'connected' | 'error';
  osc: 'disconnected' | 'connecting' | 'connected' | 'error';
  live: 'disconnected' | 'connecting' | 'connected' | 'error';
}
