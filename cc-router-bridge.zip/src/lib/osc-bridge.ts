import OSC from 'osc-js';
import { ParameterMapping, TrackInfo, OSCMessage } from '../types';

export class LiveOSCBridge {
  private osc: OSC | null = null;
  private isConnected = false;
  private selectedTrackId: number | null = null;
  private onTrackChange: ((trackId: number) => void) | null = null;
  private reconnectInterval: number | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;

  constructor(private port: number = 8080) {}

  async connect(): Promise<void> {
    try {
      // Use WebSocket bridge to UDP for OSC communication
      this.osc = new OSC({
        plugin: new OSC.WebsocketClientPlugin({
          host: 'localhost',
          port: this.port,
        })
      });

      this.osc.on('open', () => {
        this.isConnected = true;
        this.reconnectAttempts = 0;
        console.log('Connected to Live via OSC WebSocket bridge');
        this.subscribeToLiveEvents();
      });

      this.osc.on('close', () => {
        this.isConnected = false;
        console.log('OSC connection closed');
        this.attemptReconnect();
      });

      this.osc.on('error', (error: Error) => {
        console.error('OSC connection error:', error);
        this.isConnected = false;
        this.attemptReconnect();
      });

      await this.osc.open();
    } catch (error) {
      throw new Error(`Failed to connect to Live: ${error}`);
    }
  }

  private attemptReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('Max reconnection attempts reached');
      return;
    }

    if (this.reconnectInterval) {
      clearTimeout(this.reconnectInterval);
    }

    this.reconnectInterval = window.setTimeout(() => {
      this.reconnectAttempts++;
      console.log(`Attempting to reconnect... (${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
      this.connect().catch(error => {
        console.error('Reconnection failed:', error);
      });
    }, 2000 * this.reconnectAttempts); // Exponential backoff
  }

  sendCCToSelectedTrack(mapping: ParameterMapping, value: number): void {
    if (!this.isConnected || !this.osc || this.selectedTrackId === null) {
      console.warn('Cannot send CC: not connected or no track selected');
      return;
    }

    // Apply value curve transformation
    let normalizedValue = this.applyValueCurve(value / 127, mapping.curve || 'linear');
    
    // Apply min/max range if specified
    if (mapping.minValue !== undefined && mapping.maxValue !== undefined) {
      normalizedValue = mapping.minValue + (normalizedValue * (mapping.maxValue - mapping.minValue));
    }

    const address = `/live/track/${this.selectedTrackId}/device/${mapping.deviceIndex}/parameter/${mapping.parameterIndex}`;
    
    try {
      this.osc.send(new OSC.Message(address, normalizedValue));
      console.log(`Sent CC ${mapping.ccNumber} (${value}) -> ${address} (${normalizedValue.toFixed(3)})`);
    } catch (error) {
      console.error('Failed to send OSC message:', error);
    }
  }

  private applyValueCurve(value: number, curve: 'linear' | 'exponential' | 'logarithmic'): number {
    switch (curve) {
      case 'exponential':
        return Math.pow(value, 2);
      case 'logarithmic':
        return Math.sqrt(value);
      case 'linear':
      default:
        return value;
    }
  }

  private subscribeToLiveEvents(): void {
    if (!this.osc) return;

    // Listen for track selection messages from Live
    this.osc.on('/live/track/selected', (message: OSC.Message) => {
      const trackId = message.args[0] as number;
      this.selectedTrackId = trackId;
      
      if (this.onTrackChange) {
        this.onTrackChange(trackId);
      }
      
      console.log(`Track selection changed to: ${trackId}`);
    });

    // Listen for track info updates
    this.osc.on('/live/track/info', (message: OSC.Message) => {
      // Handle track info updates
      console.log('Track info updated:', message.args);
    });

    // Request initial track selection
    this.requestTrackSelection();
  }

  requestTrackSelection(): void {
    if (!this.osc || !this.isConnected) return;
    
    try {
      this.osc.send(new OSC.Message('/live/track/get_selected', []));
    } catch (error) {
      console.error('Failed to request track selection:', error);
    }
  }

  requestTrackList(): void {
    if (!this.osc || !this.isConnected) return;
    
    try {
      this.osc.send(new OSC.Message('/live/tracks/get_all', []));
    } catch (error) {
      console.error('Failed to request track list:', error);
    }
  }

  setSelectedTrack(trackId: number): void {
    this.selectedTrackId = trackId;
    
    if (this.osc && this.isConnected) {
      try {
        this.osc.send(new OSC.Message('/live/track/select', [trackId]));
      } catch (error) {
        console.error('Failed to set selected track:', error);
      }
    }
  }

  onTrackSelectionChange(callback: (trackId: number) => void): void {
    this.onTrackChange = callback;
  }

  disconnect(): void {
    if (this.reconnectInterval) {
      clearTimeout(this.reconnectInterval);
      this.reconnectInterval = null;
    }

    if (this.osc) {
      this.osc.close();
      this.osc = null;
    }
    
    this.isConnected = false;
  }

  getConnectionStatus(): boolean {
    return this.isConnected;
  }

  getSelectedTrackId(): number | null {
    return this.selectedTrackId;
  }
}
