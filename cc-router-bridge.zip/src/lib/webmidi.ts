import { MIDIMessage } from '../types';

export class WebMIDIController {
  private midiAccess: MIDIAccess | null = null;
  private selectedDevice: MIDIInput | null = null;
  private onCCMessage: ((message: MIDIMessage) => void) | null = null;
  private onDeviceChange: (() => void) | null = null;

  async initialize(): Promise<void> {
    try {
      this.midiAccess = await navigator.requestMIDIAccess({ sysex: false });
      
      // Listen for device connection changes
      this.midiAccess.onstatechange = () => {
        if (this.onDeviceChange) {
          this.onDeviceChange();
        }
      };
      
      console.log('WebMIDI initialized successfully');
    } catch (error) {
      throw new Error(`WebMIDI not supported: ${error}`);
    }
  }

  getAvailableDevices(): MIDIInput[] {
    if (!this.midiAccess) return [];
    return Array.from(this.midiAccess.inputs.values());
  }

  selectDevice(deviceId: string): boolean {
    if (!this.midiAccess) return false;
    
    const device = this.midiAccess.inputs.get(deviceId);
    if (!device) return false;

    // Disconnect previous device
    if (this.selectedDevice) {
      this.selectedDevice.onmidimessage = null;
      console.log(`Disconnected from ${this.selectedDevice.name}`);
    }

    this.selectedDevice = device;
    this.selectedDevice.onmidimessage = (event) => {
      this.handleMIDIMessage(event);
    };

    console.log(`Connected to ${device.name}`);
    return true;
  }

  private handleMIDIMessage(event: MIDIMessageEvent): void {
    const [status, data1, data2] = event.data;
    
    // Check if it's a CC message (0xB0-0xBF)
    if ((status & 0xF0) === 0xB0) {
      const channel = status & 0x0F;
      const ccNumber = data1;
      const value = data2;

      const message: MIDIMessage = {
        ccNumber,
        value,
        channel,
        timestamp: event.timeStamp || Date.now()
      };

      if (this.onCCMessage) {
        this.onCCMessage(message);
      }
    }
  }

  onCC(callback: (message: MIDIMessage) => void): void {
    this.onCCMessage = callback;
  }

  onDeviceListChange(callback: () => void): void {
    this.onDeviceChange = callback;
  }

  disconnect(): void {
    if (this.selectedDevice) {
      this.selectedDevice.onmidimessage = null;
      this.selectedDevice = null;
    }
  }

  getSelectedDevice(): MIDIInput | null {
    return this.selectedDevice;
  }

  isSupported(): boolean {
    return 'requestMIDIAccess' in navigator;
  }
}
