import React, { useEffect, useState } from 'react';
import { WebMIDIController } from './lib/webmidi';
import { LiveOSCBridge } from './lib/osc-bridge';
import { useAppStore } from './store';
import { ConnectionStatus } from './components/ConnectionStatus';
import { MIDIDeviceSelector } from './components/MIDIDeviceSelector';
import { ParameterMappingEditor } from './components/ParameterMappingEditor';
import { MIDIActivityMonitor } from './components/MIDIActivityMonitor';
import { PresetManager } from './components/PresetManager';
import { Settings, Info } from 'lucide-react';

function App() {
  const {
    setAvailableDevices,
    setSelectedDevice,
    setLastCCMessage,
    setConnectionStatus,
    selectedDeviceId,
    mappings
  } = useAppStore();

  const [midiController] = useState(() => new WebMIDIController());
  const [oscBridge] = useState(() => new LiveOSCBridge());
  const [showSettings, setShowSettings] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  useEffect(() => {
    initializeConnections();
    
    return () => {
      midiController.disconnect();
      oscBridge.disconnect();
    };
  }, []);

  const initializeConnections = async () => {
    // Initialize MIDI
    try {
      setConnectionStatus('midi', 'connecting');
      
      if (!midiController.isSupported()) {
        throw new Error('WebMIDI not supported in this browser');
      }
      
      await midiController.initialize();
      
      const devices = midiController.getAvailableDevices();
      setAvailableDevices(devices);
      setConnectionStatus('midi', 'connected');

      // Set up MIDI message handling
      midiController.onCC((message) => {
        setLastCCMessage(message);
        handleCCMessage(message);
      });

      // Listen for device changes
      midiController.onDeviceListChange(() => {
        const updatedDevices = midiController.getAvailableDevices();
        setAvailableDevices(updatedDevices);
      });

    } catch (error) {
      console.error('MIDI initialization failed:', error);
      setConnectionStatus('midi', 'error');
    }

    // Initialize OSC Bridge
    try {
      setConnectionStatus('osc', 'connecting');
      await oscBridge.connect();
      setConnectionStatus('osc', 'connected');
      setConnectionStatus('live', 'connected');

      // Set up track selection monitoring
      oscBridge.onTrackSelectionChange((trackId) => {
        console.log('Track selection changed to:', trackId);
      });

    } catch (error) {
      console.error('OSC bridge initialization failed:', error);
      setConnectionStatus('osc', 'error');
      setConnectionStatus('live', 'error');
    }
  };

  const handleCCMessage = (message: any) => {
    const mapping = mappings.find(m => m.ccNumber === message.ccNumber);
    if (mapping && oscBridge.getConnectionStatus()) {
      oscBridge.sendCCToSelectedTrack(mapping, message.value);
    }
  };

  const handleDeviceSelect = (deviceId: string) => {
    if (deviceId) {
      const success = midiController.selectDevice(deviceId);
      if (success) {
        setSelectedDevice(deviceId);
      }
    } else {
      midiController.disconnect();
      setSelectedDevice(null);
    }
  };

  const refreshDevices = () => {
    const devices = midiController.getAvailableDevices();
    setAvailableDevices(devices);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">CC Router Bridge</h1>
            <p className="text-gray-400 text-sm">
              Launch Control XL3 → WebMIDI → Ableton Live
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setShowInfo(true)}
              className="p-2 text-gray-400 hover:text-white transition-colors"
              title="Info & Setup"
            >
              <Info className="h-5 w-5" />
            </button>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 text-gray-400 hover:text-white transition-colors"
              title="Settings"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column */}
          <div className="space-y-6">
            <ConnectionStatus />
            <MIDIDeviceSelector
              onDeviceSelect={handleDeviceSelect}
              onRefresh={refreshDevices}
            />
            <PresetManager />
          </div>

          {/* Middle Column */}
          <div className="space-y-6">
            <ParameterMappingEditor />
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            <MIDIActivityMonitor />
          </div>
        </div>
      </main>

      {/* Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Setup Instructions</h2>
              <button
                onClick={() => setShowInfo(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4 text-sm">
              <div>
                <h3 className="font-semibold text-ableton-400 mb-2">1. Browser Setup</h3>
                <p className="text-gray-300">
                  This app requires WebMIDI support. Works best in Chrome, Edge, or Opera.
                  Make sure to allow MIDI access when prompted.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-ableton-400 mb-2">2. Max for Live Device</h3>
                <p className="text-gray-300 mb-2">
                  You need to install the OSC receiver Max for Live device in your Ableton Live set:
                </p>
                <ol className="list-decimal list-inside text-gray-400 space-y-1 ml-4">
                  <li>Download the osc-receiver.amxd device from the project</li>
                  <li>Drop it on any track in your Live set</li>
                  <li>The device will listen for OSC messages on port 8080</li>
                </ol>
              </div>
              
              <div>
                <h3 className="font-semibold text-ableton-400 mb-2">3. Launch Control XL3</h3>
                <p className="text-gray-300 mb-2">
                  Configure your Launch Control XL3:
                </p>
                <ul className="list-disc list-inside text-gray-400 space-y-1 ml-4">
                  <li>Connect via USB</li>
                  <li>Set to a custom mode (not DAW control mode)</li>
                  <li>Default CC mappings: CC 13-20 for the top row of knobs</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-ableton-400 mb-2">4. Usage</h3>
                <ul className="list-disc list-inside text-gray-400 space-y-1 ml-4">
                  <li>Select your MIDI device from the dropdown</li>
                  <li>Configure parameter mappings</li>
                  <li>Select a track in Live</li>
                  <li>Move controls on XL3 to control the selected track's first device</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">Settings</h2>
              <button
                onClick={() => setShowSettings(false)}
                className="text-gray-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  OSC Bridge Port
                </label>
                <input
                  type="number"
                  value="8080"
                  disabled
                  className="w-full bg-gray-700 border border-gray-600 rounded-md px-3 py-2 text-white"
                />
                <p className="text-xs text-gray-400 mt-1">
                  Port 8080 is used for WebSocket to UDP bridge
                </p>
              </div>
              
              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  Debug Mode
                </label>
                <button className="w-full bg-gray-700 hover:bg-gray-600 text-white px-3 py-2 rounded-md transition-colors">
                  Enable Console Logging
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
