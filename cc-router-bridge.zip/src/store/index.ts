import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { AppState, ParameterMapping, MIDIMessage, ConnectionStatus } from '../types';

interface AppStore extends AppState {
  // Actions
  setConnected: (connected: boolean) => void;
  setSelectedDevice: (deviceId: string | null) => void;
  setAvailableDevices: (devices: MIDIInput[]) => void;
  addMapping: (mapping: ParameterMapping) => void;
  updateMapping: (id: string, updates: Partial<ParameterMapping>) => void;
  removeMapping: (id: string) => void;
  setMappings: (mappings: ParameterMapping[]) => void;
  setSelectedTrack: (trackId: number | null) => void;
  setLastCCMessage: (message: MIDIMessage | null) => void;
  
  // Connection status
  connectionStatus: ConnectionStatus;
  setConnectionStatus: (service: keyof ConnectionStatus, status: ConnectionStatus[keyof ConnectionStatus]) => void;
  
  // Preset management
  savePreset: (name: string) => void;
  loadPreset: (name: string) => void;
  getPresets: () => string[];
  deletePreset: (name: string) => void;
}

const defaultMappings: ParameterMapping[] = [
  {
    id: '1',
    ccNumber: 13,
    deviceIndex: 0,
    parameterIndex: 0,
    parameterName: 'Device 1 - Param 1',
    curve: 'linear'
  },
  {
    id: '2',
    ccNumber: 14,
    deviceIndex: 0,
    parameterIndex: 1,
    parameterName: 'Device 1 - Param 2',
    curve: 'linear'
  },
  {
    id: '3',
    ccNumber: 15,
    deviceIndex: 0,
    parameterIndex: 2,
    parameterName: 'Device 1 - Param 3',
    curve: 'linear'
  },
  {
    id: '4',
    ccNumber: 16,
    deviceIndex: 0,
    parameterIndex: 3,
    parameterName: 'Device 1 - Param 4',
    curve: 'linear'
  },
  {
    id: '5',
    ccNumber: 17,
    deviceIndex: 0,
    parameterIndex: 4,
    parameterName: 'Device 1 - Param 5',
    curve: 'linear'
  },
  {
    id: '6',
    ccNumber: 18,
    deviceIndex: 0,
    parameterIndex: 5,
    parameterName: 'Device 1 - Param 6',
    curve: 'linear'
  },
  {
    id: '7',
    ccNumber: 19,
    deviceIndex: 0,
    parameterIndex: 6,
    parameterName: 'Device 1 - Param 7',
    curve: 'linear'
  },
  {
    id: '8',
    ccNumber: 20,
    deviceIndex: 0,
    parameterIndex: 7,
    parameterName: 'Device 1 - Param 8',
    curve: 'linear'
  },
];

export const useAppStore = create<AppStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    isConnected: false,
    selectedDeviceId: null,
    availableDevices: [],
    mappings: defaultMappings,
    selectedTrackId: null,
    tracks: [],
    lastCCMessage: null,
    
    connectionStatus: {
      midi: 'disconnected',
      osc: 'disconnected',
      live: 'disconnected'
    },

    // Actions
    setConnected: (connected) => set({ isConnected: connected }),
    
    setSelectedDevice: (deviceId) => set({ selectedDeviceId: deviceId }),
    
    setAvailableDevices: (devices) => set({ availableDevices: devices }),
    
    addMapping: (mapping) => set((state) => ({
      mappings: [...state.mappings, mapping]
    })),
    
    updateMapping: (id, updates) => set((state) => ({
      mappings: state.mappings.map(mapping =>
        mapping.id === id ? { ...mapping, ...updates } : mapping
      )
    })),
    
    removeMapping: (id) => set((state) => ({
      mappings: state.mappings.filter(mapping => mapping.id !== id)
    })),
    
    setMappings: (mappings) => set({ mappings }),
    
    setSelectedTrack: (trackId) => set({ selectedTrackId: trackId }),
    
    setLastCCMessage: (message) => set({ lastCCMessage: message }),
    
    setConnectionStatus: (service, status) => set((state) => ({
      connectionStatus: {
        ...state.connectionStatus,
        [service]: status
      }
    })),

    // Preset management
    savePreset: (name) => {
      const { mappings } = get();
      const presets = JSON.parse(localStorage.getItem('cc-router-presets') || '{}');
      presets[name] = mappings;
      localStorage.setItem('cc-router-presets', JSON.stringify(presets));
    },

    loadPreset: (name) => {
      const presets = JSON.parse(localStorage.getItem('cc-router-presets') || '{}');
      if (presets[name]) {
        set({ mappings: presets[name] });
      }
    },

    getPresets: () => {
      const presets = JSON.parse(localStorage.getItem('cc-router-presets') || '{}');
      return Object.keys(presets);
    },

    deletePreset: (name) => {
      const presets = JSON.parse(localStorage.getItem('cc-router-presets') || '{}');
      delete presets[name];
      localStorage.setItem('cc-router-presets', JSON.stringify(presets));
    }
  }))
);

// Persist mappings to localStorage
useAppStore.subscribe(
  (state) => state.mappings,
  (mappings) => {
    localStorage.setItem('cc-router-mappings', JSON.stringify(mappings));
  }
);

// Load mappings from localStorage on initialization
const savedMappings = localStorage.getItem('cc-router-mappings');
if (savedMappings) {
  try {
    const mappings = JSON.parse(savedMappings);
    useAppStore.getState().setMappings(mappings);
  } catch (error) {
    console.error('Failed to load saved mappings:', error);
  }
}
