// osc-receiver.js - Max for Live OSC WebSocket to UDP bridge
autowatch = 1;
outlets = 2;

var websocketServer;
var udpSender;
var isRunning = false;
var wsPort = 8080;
var udpPort = 9000;

function loadbang() {
    post("CC Router OSC Bridge loading...\n");
    setupWebSocketServer();
    setupUDPSender();
    setupLiveObservers();
    post("CC Router OSC Bridge ready on port " + wsPort + "\n");
}

function setupWebSocketServer() {
    try {
        // Create WebSocket server to receive from web browser
        websocketServer = new LiveAPI("websocket_server");
        websocketServer.property = "port";
        websocketServer.set("port", wsPort);
        
        // Set up message handling
        websocketServer.property = "message_callback";
        websocketServer.set("message_callback", "handleWebSocketMessage");
        
        isRunning = true;
        post("WebSocket server started on port " + wsPort + "\n");
    } catch (error) {
        post("Failed to create WebSocket server: " + error + "\n");
    }
}

function setupUDPSender() {
    try {
        // Create UDP sender for local OSC communication
        udpSender = new LiveAPI("udp_sender");
        udpSender.property = "host";
        udpSender.set("host", "127.0.0.1");
        udpSender.property = "port";
        udpSender.set("port", udpPort);
        
        post("UDP sender configured for localhost:" + udpPort + "\n");
    } catch (error) {
        post("Failed to create UDP sender: " + error + "\n");
    }
}

function setupLiveObservers() {
    try {
        // Set up track selection observer
        var trackObserver = new LiveAPI("live_set view");
        trackObserver.property = "selected_track";
        trackObserver.id = "track_selection_observer";
        
        // Set up track change notifications
        trackObserver.property = "selected_track";
        
        post("Live observers configured\n");
    } catch (error) {
        post("Failed to setup Live observers: " + error + "\n");
    }
}

// Handle incoming WebSocket messages from browser
function handleWebSocketMessage(message) {
    try {
        var parsed = JSON.parse(message);
        
        if (parsed.address && parsed.args) {
            routeOSCMessage(parsed.address, parsed.args);
        }
    } catch (error) {
        post("Error parsing WebSocket message: " + error + "\n");
    }
}

// Route OSC messages to Live parameters
function routeOSCMessage(address, args) {
    try {
        // Parse address: /live/track/1/device/0/parameter/2
        var parts = address.split('/');
        
        if (parts.length >= 8 && parts[1] === 'live' && parts[2] === 'track') {
            var trackId = parseInt(parts[3]);
            var deviceIndex = parseInt(parts[5]);
            var paramIndex = parseInt(parts[7]);
            var value = args[0];
            
            setLiveParameter(trackId, deviceIndex, paramIndex, value);
        } else if (parts[1] === 'live' && parts[2] === 'track' && parts[3] === 'get_selected') {
            sendSelectedTrackInfo();
        } else if (parts[1] === 'live' && parts[2] === 'track' && parts[3] === 'select') {
            selectTrack(args[0]);
        }
    } catch (error) {
        post("Error routing OSC message: " + error + "\n");
    }
}

function setLiveParameter(trackId, deviceIndex, paramIndex, value) {
    try {
        // Get the selected track (we route to selected track regardless of trackId for security)
        var selectedTrack = new LiveAPI("live_set view selected_track");
        
        if (!selectedTrack || selectedTrack.id === "0") {
            post("No track selected\n");
            return;
        }
        
        // Get devices on the selected track
        var devices = selectedTrack.get("devices");
        if (deviceIndex >= devices.length) {
            post("Device index " + deviceIndex + " not found on selected track\n");
            return;
        }
        
        // Get the target device
        var device = new LiveAPI("live_set view selected_track devices " + deviceIndex);
        var parameters = device.get("parameters");
        
        if (paramIndex >= parameters.length) {
            post("Parameter index " + paramIndex + " not found on device\n");
            return;
        }
        
        // Set the parameter value
        device.set("parameters " + paramIndex + " value", value);
        
        var trackName = selectedTrack.get("name");
        var deviceName = device.get("name");
        
        post("Set " + trackName + " > " + deviceName + " param " + paramIndex + " = " + value.toFixed(3) + "\n");
        
        // Send confirmation back to browser
        sendWebSocketMessage({
            type: "parameter_changed",
            track: trackName,
            device: deviceName,
            parameter: paramIndex,
            value: value
        });
        
    } catch (error) {
        post("Error setting Live parameter: " + error + "\n");
    }
}

function sendSelectedTrackInfo() {
    try {
        var selectedTrack = new LiveAPI("live_set view selected_track");
        
        if (selectedTrack && selectedTrack.id !== "0") {
            var trackInfo = {
                type: "track_selected",
                id: selectedTrack.get("id"),
                name: selectedTrack.get("name"),
                devices: selectedTrack.get("devices").length
            };
            
            sendWebSocketMessage(trackInfo);
        }
    } catch (error) {
        post("Error getting selected track info: " + error + "\n");
    }
}

function selectTrack(trackIndex) {
    try {
        var liveSet = new LiveAPI("live_set");
        var tracks = liveSet.get("tracks");
        
        if (trackIndex >= 0 && trackIndex < tracks.length) {
            var track = new LiveAPI("live_set tracks " + trackIndex);
            var view = new LiveAPI("live_set view");
            view.set("selected_track", track.get("id"));
            
            post("Selected track " + trackIndex + ": " + track.get("name") + "\n");
        }
    } catch (error) {
        post("Error selecting track: " + error + "\n");
    }
}

function sendWebSocketMessage(data) {
    try {
        if (websocketServer && isRunning) {
            var message = JSON.stringify(data);
            websocketServer.call("send_message", message);
        }
    } catch (error) {
        post("Error sending WebSocket message: " + error + "\n");
    }
}

// Observer callback for track selection changes
function track_selection_observer() {
    try {
        var selectedTrack = new LiveAPI("live_set view selected_track");
        
        if (selectedTrack && selectedTrack.id !== "0") {
            var trackInfo = {
                type: "track_changed",
                id: selectedTrack.get("id"),
                name: selectedTrack.get("name")
            };
            
            sendWebSocketMessage(trackInfo);
            post("Track selection changed to: " + selectedTrack.get("name") + "\n");
        }
    } catch (error) {
        post("Error in track selection observer: " + error + "\n");
    }
}

// Cleanup function
function closebang() {
    if (websocketServer) {
        websocketServer.call("close");
    }
    if (udpSender) {
        udpSender.call("close");
    }
    isRunning = false;
    post("CC Router OSC Bridge closed\n");
}

// Manual control functions for testing
function test_parameter(trackIndex, deviceIndex, paramIndex, value) {
    setLiveParameter(trackIndex, deviceIndex, paramIndex, value);
}

function get_track_info() {
    sendSelectedTrackInfo();
}

function restart_server() {
    closebang();
    loadbang();
}

// Debug functions
function list_tracks() {
    try {
        var liveSet = new LiveAPI("live_set");
        var tracks = liveSet.get("tracks");
        
        post("=== Track List ===\n");
        for (var i = 0; i < tracks.length; i++) {
            var track = new LiveAPI("live_set tracks " + i);
            post("Track " + i + ": " + track.get("name") + "\n");
        }
    } catch (error) {
        post("Error listing tracks: " + error + "\n");
    }
}

function list_devices() {
    try {
        var selectedTrack = new LiveAPI("live_set view selected_track");
        
        if (!selectedTrack || selectedTrack.id === "0") {
            post("No track selected\n");
            return;
        }
        
        var devices = selectedTrack.get("devices");
        var trackName = selectedTrack.get("name");
        
        post("=== Devices on " + trackName + " ===\n");
        for (var i = 0; i < devices.length; i++) {
            var device = new LiveAPI("live_set view selected_track devices " + i);
            var paramCount = device.get("parameters").length;
            post("Device " + i + ": " + device.get("name") + " (" + paramCount + " parameters)\n");
        }
    } catch (error) {
        post("Error listing devices: " + error + "\n");
    }
}

function list_parameters(deviceIndex) {
    try {
        var selectedTrack = new LiveAPI("live_set view selected_track");
        
        if (!selectedTrack || selectedTrack.id === "0") {
            post("No track selected\n");
            return;
        }
        
        var device = new LiveAPI("live_set view selected_track devices " + deviceIndex);
        var parameters = device.get("parameters");
        var deviceName = device.get("name");
        
        post("=== Parameters on " + deviceName + " ===\n");
        for (var i = 0; i < parameters.length; i++) {
            var param = new LiveAPI("live_set view selected_track devices " + deviceIndex + " parameters " + i);
            var name = param.get("name");
            var value = param.get("value");
            post("Param " + i + ": " + name + " = " + value + "\n");
        }
    } catch (error) {
        post("Error listing parameters: " + error + "\n");
    }
}
