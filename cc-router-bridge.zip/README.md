# CC Router Bridge

A TypeScript/React web application that routes MIDI CC messages from a Launch Control XL3 to the currently selected track in Ableton Live using WebMIDI and OSC.

## Features

- ✅ **WebMIDI Integration** - Direct browser access to MIDI devices
- ✅ **Track-Aware Routing** - CC messages only affect the selected track
- ✅ **Real-time Parameter Mapping** - Visual editor for CC-to-parameter assignments
- ✅ **Live Activity Monitoring** - See MIDI messages in real-time
- ✅ **Preset Management** - Save/load mapping configurations
- ✅ **Import/Export** - Share mappings between projects
- ✅ **TypeScript Safety** - Full type safety throughout
- ✅ **No Local Server** - Runs entirely in the browser

## Architecture

```
Launch Control XL3 → Browser (WebMIDI) → WebSocket → Max for Live → Ableton Live
```

## Quick Start

### 1. Install Dependencies

```bash
pnpm install
```

### 2. Start Development Server

```bash
pnpm dev
```

### 3. Install Max for Live Device

1. Copy `max-device/osc-receiver.js` to your Live set
2. Create a simple Max patcher with:
   - `[js osc-receiver.js]` object
   - Drop this device on any track in Live

### 4. Configure Launch Control XL3

1. Connect XL3 via USB
2. Set to a custom mode (not DAW control)
3. Default CCs: 13-20 for top row knobs

### 5. Use the Application

1. Open the web app in Chrome/Edge/Opera
2. Allow MIDI access when prompted
3. Select your XL3 from the device dropdown
4. Configure parameter mappings
5. Select a track in Live
6. Move XL3 controls to affect the selected track's first device

## Project Structure

```
cc-router-bridge/
├── src/
│   ├── components/          # React components
│   ├── lib/                 # Core libraries (WebMIDI, OSC)
│   ├── store/              # Zustand state management
│   ├── types/              # TypeScript definitions
│   └── App.tsx             # Main application
├── max-device/             # Max for Live device
└── package.json            # Dependencies & scripts
```

## Core Components

### WebMIDI Controller (`src/lib/webmidi.ts`)
- Handles browser MIDI access
- Device selection and message routing
- Real-time CC message processing

### OSC Bridge (`src/lib/osc-bridge.ts`)
- WebSocket to OSC communication
- Track selection monitoring
- Parameter value transformation

### State Management (`src/store/index.ts`)
- Zustand-based global state
- Persistent mapping storage
- Preset management

## Configuration

### Default Launch Control XL3 Mappings

| Control | CC Number | Parameter Index |
|---------|-----------|----------------|
| Knob 1  | CC 13     | Parameter 0    |
| Knob 2  | CC 14     | Parameter 1    |
| Knob 3  | CC 15     | Parameter 2    |
| Knob 4  | CC 16     | Parameter 3    |
| Knob 5  | CC 17     | Parameter 4    |
| Knob 6  | CC 18     | Parameter 5    |
| Knob 7  | CC 19     | Parameter 6    |
| Knob 8  | CC 20     | Parameter 7    |

### Value Curves

- **Linear**: Direct 1:1 mapping
- **Exponential**: Squared response (more precision at low values)
- **Logarithmic**: Square root response (more precision at high values)

### Custom Ranges

Set `minValue` and `maxValue` to limit parameter range:
- `minValue: 0.2, maxValue: 0.8` → CC 0-127 maps to 20%-80%

## Max for Live Device

The `osc-receiver.js` device provides:

- **WebSocket Server** - Receives messages from browser
- **Live Integration** - Direct parameter control
- **Track Monitoring** - Observes selection changes
- **Debug Functions** - Development helpers

### Debug Commands (in Max console)

```javascript
list_tracks()              // Show all tracks
list_devices()            // Show devices on selected track
list_parameters(0)        // Show parameters on device 0
test_parameter(0,0,1,0.5) // Test parameter control
restart_server()          // Restart WebSocket server
```

## Development

### Available Scripts

```bash
pnpm dev          # Start development server
pnpm build        # Build for production
pnpm preview      # Preview production build
pnpm lint         # Run ESLint
pnpm type-check   # TypeScript checking
```

### Live Reloading

The application supports hot reloading during development:
- Edit TypeScript/React files → Browser auto-updates
- Edit Max device → Reload via Max console
- Mappings persist in localStorage

### Browser Compatibility

| Browser | WebMIDI Support | Status |
|---------|----------------|--------|
| Chrome  | ✅ Full        | ✅ Recommended |
| Edge    | ✅ Full        | ✅ Recommended |
| Opera   | ✅ Full        | ✅ Supported |
| Firefox | ❌ None        | ❌ Not supported |
| Safari  | ❌ None        | ❌ Not supported |

## Troubleshooting

### MIDI Device Not Detected

1. **Check browser support** - Use Chrome, Edge, or Opera
2. **Allow MIDI access** - Click "Allow" when prompted
3. **Reconnect device** - Unplug/replug XL3 USB
4. **Refresh device list** - Click refresh button in app

### OSC Connection Failed

1. **Max device loaded?** - Ensure osc-receiver.js is running in Live
2. **Port conflicts** - Check no other apps use port 8080
3. **Firewall** - Allow local WebSocket connections
4. **Restart** - Reload Max device and web app

### No Parameter Control

1. **Track selected?** - Select a track with devices in Live
2. **Device exists?** - Check device index in mapping (usually 0)
3. **Parameter exists?** - Verify parameter index for your device
4. **Mapping configured?** - Check CC numbers match your controller

### Performance Issues

1. **Reduce mappings** - Only map needed parameters
2. **Close other MIDI apps** - Avoid conflicts
3. **Browser resources** - Close unnecessary tabs
4. **MIDI message rate** - Some controllers send very fast updates

## Advanced Usage

### Custom Plugin Integration

For specific plugins, discover parameter indices:

1. Select track with your plugin
2. Open browser console
3. Use Max device debug: `list_parameters(0)`
4. Update mappings with correct indices

### Multiple Device Support

Configure different CC ranges for multiple controllers:
- XL3 Top Row: CC 13-20
- XL3 Bottom Row: CC 21-28
- Other controllers: CC 1-8, etc.

### Preset Workflows

1. **Save per plugin** - Create presets for each plugin type
2. **Export/Import** - Share mappings between projects
3. **Version control** - Export JSON files to Git repos
4. **Backup** - Regular preset exports recommended

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes with TypeScript/React best practices
4. Test with actual hardware
5. Submit pull request

## License

MIT License - see LICENSE file for details

## Support

For issues and questions:
1. Check troubleshooting section
2. Review browser console for errors
3. Test with Max device debug functions
4. Create GitHub issue with details
